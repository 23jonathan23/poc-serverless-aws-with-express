const teste = require("./teste")
const teste2 = require("./teste2")

module.exports = { teste, teste2 }
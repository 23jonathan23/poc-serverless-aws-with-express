const recipe = require("./recipe")
const user = require("./user")

module.exports = { recipe, user }
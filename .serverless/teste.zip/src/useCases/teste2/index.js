const teste2 = (req, res) => {
    res.status(200).json({ message: "funcionou legal" })
}

module.exports = teste2
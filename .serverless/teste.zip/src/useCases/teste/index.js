const teste = (req, res) => {
    res.status(200).json({ message: "funcionou legal" })
}

module.exports = teste
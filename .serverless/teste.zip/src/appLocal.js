const app = require('./app')

const port = 3300

app.listen(port, () => {
    console.log(`Listening at port ${port}`)
})
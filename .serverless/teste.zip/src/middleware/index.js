const { validateToken } = require('./authentication')

module.exports = { validateToken }